from configurator import configure
import sys

configure(new_values_path=sys.argv[1], comagic_web_path=sys.argv[2])
